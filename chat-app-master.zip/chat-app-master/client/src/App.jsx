import Chat from "./components/Chat";

function App() {
  return (
    <>
      <Chat />
    </>
  );
}

export default App;
